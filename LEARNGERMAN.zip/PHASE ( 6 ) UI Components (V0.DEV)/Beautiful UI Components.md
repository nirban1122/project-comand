Create beautiful React components for my German learning app:

1. HeroSection
   - Welcome banner
   - Call to action buttons
   - Animated background
   - Mobile responsive

2. CourseCard
   - Course image/icon
   - Level badge (A1, A2, etc)
   - Progress bar
   - Enrollment button
   - Stars/rating (optional)

3. LessonCard
   - Lesson title
   - Completed checkmark
   - Difficulty indicator
   - Preview text
   - Click to go to lesson

4. ExerciseCard
   - Exercise title
   - Type indicator (multiple choice, etc)
   - Difficulty
   - XP reward
   - Status (completed/not attempted)

5. StatCard
   - Icon + number + label
   - Animated counter
   - Color coded

6. NavigationBar
   - Logo
   - Navigation links
   - User profile dropdown
   - Mobile hamburger menu

7. Footer
   - Links
   - Contact info
   - Social media

Use:
- Shadcn/UI components
- Tailwind CSS
- Modern design
- Smooth animations
- Accessibility features

For each component, provide:
- Full JSX code
- Tailwind styling
- TypeScript props
- Usage examples



————————————
V0.DEV WILL GIVE YOU:

Ready-to-use React components
Shadcn/UI integration
Beautiful styling
Copy directly into your project